GD Kit — shared design and editor components for the GD plugin family.
Copyright 2026 GD Music.

The implementation builds on the JUCE modules already used by each product.
It does not include or relicense JUCE, its dependencies, or product DSP.
Refer to each product's existing license and third-party notices.
