#pragma once
#include "Theme.h"

namespace gdkit {
// One instance per editor. Never change JUCE's process-global default in a host.
class LookAndFeel : public juce::LookAndFeel_V4 {
public:
    explicit LookAndFeel(Product product, float uiScale = 1.0f) : uiScale_(juce::jmax(0.5f, uiScale)) { setProduct(product); }
    const Palette& colors() const noexcept { return colors_; }
    void setProduct(Product product) {
        colors_ = palette(product);
        const auto& p = colors_;
        setColour(juce::ResizableWindow::backgroundColourId, p.background);
        setColour(juce::Label::textColourId, p.text);
        setColour(juce::Slider::textBoxTextColourId, p.text);
        setColour(juce::Slider::textBoxBackgroundColourId, juce::Colours::transparentBlack);
        setColour(juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
        setColour(juce::Slider::textBoxHighlightColourId, p.accent.withAlpha(0.2f));
        setColour(juce::Slider::rotarySliderFillColourId, p.accent);
        setColour(juce::Slider::rotarySliderOutlineColourId, p.border);
        setColour(juce::Slider::thumbColourId, p.accent);
        setColour(juce::Slider::trackColourId, p.accent);
        setColour(juce::Slider::backgroundColourId, p.border);
        setColour(juce::TextButton::buttonColourId, p.surface);
        setColour(juce::TextButton::buttonOnColourId, p.accent);
        setColour(juce::TextButton::textColourOffId, p.text);
        setColour(juce::TextButton::textColourOnId, p.background);
        setColour(juce::ToggleButton::textColourId, p.text);
        setColour(juce::ToggleButton::tickColourId, p.accent);
        setColour(juce::ComboBox::backgroundColourId, p.surface);
        setColour(juce::ComboBox::textColourId, p.text);
        setColour(juce::ComboBox::outlineColourId, p.border);
        setColour(juce::ComboBox::arrowColourId, p.muted);
        setColour(juce::PopupMenu::backgroundColourId, p.surface);
        setColour(juce::PopupMenu::textColourId, p.text);
        setColour(juce::PopupMenu::highlightedBackgroundColourId, p.accent.withAlpha(0.16f));
        setColour(juce::PopupMenu::highlightedTextColourId, p.accent);
        setColour(juce::TextEditor::backgroundColourId, p.surface);
        setColour(juce::TextEditor::textColourId, p.text);
        setColour(juce::TextEditor::outlineColourId, p.border);
        setColour(juce::TextEditor::focusedOutlineColourId, p.accent);
        setColour(juce::TextEditor::highlightColourId, p.accent.withAlpha(0.25f));
        setColour(juce::ListBox::backgroundColourId, juce::Colours::transparentBlack);
        setColour(juce::ScrollBar::thumbColourId, p.border.brighter(0.15f));
        setColour(juce::TooltipWindow::backgroundColourId, p.elevated);
        setColour(juce::TooltipWindow::textColourId, p.text);
        setColour(juce::TooltipWindow::outlineColourId, p.border);
        setColour(juce::AlertWindow::backgroundColourId, p.surface);
        setColour(juce::AlertWindow::textColourId, p.text);
    }

    juce::Font getTextButtonFont(juce::TextButton&, int height) override {
        return font((height < 36 * uiScale_ ? 12.0f : 13.0f) * uiScale_, true);
    }
    juce::Font getComboBoxFont(juce::ComboBox&) override { return font(12.0f * uiScale_); }
    juce::Font getPopupMenuFont() override { return font(13.0f * uiScale_); }

    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height, float value,
                          float start, float end, juce::Slider& slider) override {
        const auto& p = colors_;
        const bool mini = static_cast<bool>(slider.getProperties()["mini"]);
        const auto area = juce::Rectangle<float>(float(x), float(y), float(width), float(height)).reduced(mini ? 3.0f : 9.0f);
        const auto centre = area.getCentre();
        const auto radius = juce::jmax(0.0f, juce::jmin(area.getWidth(), area.getHeight()) * 0.5f);
        if (radius < 2.0f) return;
        const auto angle = start + juce::jlimit(0.0f, 1.0f, value) * (end - start);
        const auto accent = slider.findColour(juce::Slider::rotarySliderFillColourId);
        const float alpha = slider.isEnabled() ? 1.0f : 0.35f;
        const auto stroke = radius > 70 ? 3.5f : 2.5f;
        juce::Path track, active;
        track.addCentredArc(centre.x, centre.y, radius, radius, 0, start, end, true);
        active.addCentredArc(centre.x, centre.y, radius, radius, 0, start, angle, true);
        g.setColour(p.border.withAlpha(alpha));
        g.strokePath(track, juce::PathStrokeType(stroke, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        g.setColour(accent.withAlpha(alpha));
        g.strokePath(active, juce::PathStrokeType(stroke, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        const auto dial = juce::Rectangle<float>(radius * 1.66f, radius * 1.66f).withCentre(centre);
        g.setColour(p.surface); g.fillEllipse(dial);
        g.setColour(p.border.withAlpha(alpha * 0.65f)); g.drawEllipse(dial, 1.0f);
        juce::Path pointer;
        pointer.addRoundedRectangle(-1.4f, -radius * 0.66f, 2.8f, radius * 0.19f, 1.4f);
        g.setColour(accent.withAlpha(alpha));
        g.fillPath(pointer, juce::AffineTransform::rotation(angle).translated(centre.x, centre.y));
        if (mini) {
            text(g, juce::String(slider.getValue(), 0), dial.toNearestInt(), 10.0f,
                 p.text.withAlpha(alpha), true, juce::Justification::centred);
        } else if (static_cast<bool>(slider.getProperties()["gdkit.valueInside"])) {
            const auto valueWidth = juce::roundToInt(radius * 1.35f);
            text(g, slider.getTextFromValue(slider.getValue()),
                 juce::Rectangle<int>(valueWidth, 44).withCentre(centre.toInt()),
                 juce::jmin(36.0f, radius * 0.38f), p.text.withAlpha(alpha), true, juce::Justification::centred);
            text(g, slider.getName().toUpperCase(),
                 juce::Rectangle<int>(valueWidth, 20).withCentre(centre.toInt().translated(0, 31)),
                 10.0f, p.muted.withAlpha(alpha), true, juce::Justification::centred);
        }
        if (slider.hasKeyboardFocus(true)) {
            g.setColour(accent.withAlpha(0.8f)); g.drawEllipse(dial.expanded(3.0f), 1.0f);
        }
    }

    void drawButtonBackground(juce::Graphics& g, juce::Button& button, const juce::Colour&, bool over, bool down) override {
        const auto& p = colors_;
        const auto role = button.getProperties()["gdkit.role"].toString();
        const bool primary = role == "primary" || button.getComponentID() == "primary";
        const bool quiet = role == "quiet" || button.getComponentID() == "quiet";
        const bool on = button.getToggleState();
        const auto opacity = button.isEnabled() ? 1.0f : 0.35f;
        auto fill = primary ? p.accent : on ? p.accent.withAlpha(0.14f) : p.surface;
        if (quiet) fill = juce::Colours::transparentBlack;
        if (over || down) fill = primary ? fill.darker(down ? 0.15f : 0.05f) : p.elevated;
        const auto bounds = button.getLocalBounds().toFloat().reduced(0.5f);
        const auto radius = tokens::controlRadius * uiScale_;
        g.setColour(fill.withMultipliedAlpha(opacity)); g.fillRoundedRectangle(bounds, radius);
        if (!quiet) {
            g.setColour((primary || on ? p.accent : p.border).withAlpha(opacity * 0.7f));
            g.drawRoundedRectangle(bounds, radius, 1.0f);
        }
        if (button.hasKeyboardFocus(true)) {
            g.setColour(p.accent); g.drawRoundedRectangle(bounds.reduced(2.0f), juce::jmax(1.0f, radius - 2.0f), 1.0f);
        }
    }
    void drawButtonText(juce::Graphics& g, juce::TextButton& button, bool, bool) override {
        const auto primary = button.getProperties()["gdkit.role"].toString() == "primary" || button.getComponentID() == "primary";
        const auto color = primary ? colors_.background : button.getToggleState() ? colors_.accent : colors_.text;
        g.setColour(color.withAlpha(button.isEnabled() ? 1.0f : 0.4f));
        g.setFont(getTextButtonFont(button, button.getHeight()));
        const auto lines = button.getButtonText().containsChar('\n') ? 2 : 1;
        g.drawFittedText(button.getButtonText(), button.getLocalBounds().reduced(6, 0), juce::Justification::centred, lines);
    }
    void drawToggleButton(juce::Graphics& g, juce::ToggleButton& button, bool over, bool down) override {
        drawButtonBackground(g, button, colors_.surface, over, down);
        const auto on = button.getToggleState();
        text(g, button.getButtonText(), button.getLocalBounds().reduced(8, 0), 11.0f,
             (on ? colors_.accent : colors_.muted).withAlpha(button.isEnabled() ? 1.0f : 0.4f), true,
             juce::Justification::centred);
    }
private:
    Palette colors_;
    const float uiScale_;
};

inline void configureRotary(juce::Slider& slider, const juce::String& name,
                            const juce::String& description, double defaultValue, bool valueInside = false) {
    slider.setName(name); slider.setTitle(name); slider.setDescription(description); slider.setTooltip(description);
    slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    slider.setRotaryParameters(juce::MathConstants<float>::pi * 1.23f, juce::MathConstants<float>::pi * 2.77f, true);
    slider.setTextBoxStyle(valueInside ? juce::Slider::NoTextBox : juce::Slider::TextBoxBelow, false, 78, 23);
    slider.setDoubleClickReturnValue(true, defaultValue);
    slider.setVelocityModeParameters(1.0, 1, 0.0, true, juce::ModifierKeys::shiftModifier);
    slider.setWantsKeyboardFocus(true);
    slider.getProperties().set("gdkit.valueInside", valueInside);
}
} // namespace gdkit
