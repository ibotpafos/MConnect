#pragma once
#include "Tokens.h"
#include <juce_gui_basics/juce_gui_basics.h>
#include <cmath>

namespace gdkit {
enum class Product { doubler, mconnect, leveler, choir, vocaltune, vocalclean, dynamics, ydownload, riser, conflict };

struct Palette {
    juce::Colour background {tokens::background}, surface {tokens::surface}, elevated {tokens::elevated};
    juce::Colour border {tokens::border}, text {tokens::text}, muted {tokens::muted};
    juce::Colour accent, success {tokens::success}, warning {tokens::warning}, danger {tokens::danger};
};

inline Palette palette(Product product) {
    std::uint32_t accent = tokens::doublerAccent;
    switch (product) {
        case Product::doubler: accent = tokens::doublerAccent; break;
        case Product::mconnect: accent = tokens::mconnectAccent; break;
        case Product::leveler: accent = tokens::levelerAccent; break;
        case Product::choir: accent = tokens::choirAccent; break;
        case Product::vocaltune: accent = tokens::vocaltuneAccent; break;
        case Product::vocalclean: accent = tokens::vocalcleanAccent; break;
        case Product::dynamics: accent = tokens::dynamicsAccent; break;
        case Product::ydownload: accent = tokens::ydownloadAccent; break;
        case Product::riser: accent = tokens::riserAccent; break;
        case Product::conflict: accent = tokens::conflictAccent; break;
    }
    Palette result; result.accent = juce::Colour(accent); return result;
}

inline juce::Font font(float size, bool bold = false) {
    return juce::Font(juce::FontOptions(tokens::fontFamily, size, bold ? juce::Font::bold : juce::Font::plain));
}

inline void text(juce::Graphics& g, const juce::String& value, juce::Rectangle<int> bounds,
                 float size, juce::Colour color, bool bold = false,
                 juce::Justification alignment = juce::Justification::centredLeft) {
    g.setColour(color); g.setFont(font(size, bold)); g.drawText(value, bounds, alignment, true);
}

// Optional chrome: waveform and piano-roll editors can remain borderless.
inline void paintHeader(juce::Graphics& g, juce::Rectangle<int> bounds, const Palette& p,
                        const juce::String& name, const juce::String& category) {
    auto mark = bounds.removeFromLeft(34);
    text(g, "GD", mark.withHeight(28), 17, p.accent, true);
    bounds.removeFromLeft(14);
    text(g, name, bounds.withHeight(27), 20, p.text, true);
    text(g, category, bounds.withTrimmedTop(28).withHeight(17), 10.5f, p.muted);
}

inline void paintMeter(juce::Graphics& g, juce::Rectangle<float> bounds, float peak, const Palette& p) {
    if (!std::isfinite(peak)) peak = 0.0f;
    const auto db = peak > 0.0f ? juce::jmax(-60.0f, 20.0f * std::log10(peak)) : -60.0f;
    const auto fill = juce::jlimit(0.0f, 1.0f, (db + 60.0f) / 60.0f);
    const auto radius = juce::jmin(2.0f, bounds.getHeight() * 0.5f);
    g.setColour(p.border); g.fillRoundedRectangle(bounds, radius);
    if (fill > 0.0f) {
        g.setColour(peak >= 1.0f ? p.danger : p.accent);
        g.fillRoundedRectangle(bounds.withWidth(bounds.getWidth() * fill), radius);
    }
}
} // namespace gdkit
